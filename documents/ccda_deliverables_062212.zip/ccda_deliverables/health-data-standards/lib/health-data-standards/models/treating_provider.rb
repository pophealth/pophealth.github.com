class TreatingProvider < Entry
  field :treatingProviderID, type: Integer
end
