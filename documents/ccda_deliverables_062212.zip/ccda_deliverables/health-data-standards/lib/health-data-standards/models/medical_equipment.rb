class MedicalEquipment < Entry
  
  field :manufacturer, type: String
   
end