class VitalSign < LabResult
end
