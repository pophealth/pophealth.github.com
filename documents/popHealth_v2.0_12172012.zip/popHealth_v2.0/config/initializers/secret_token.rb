# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PopHealth::Application.config.secret_token = 'd2d8152dfb0736f5ae682c88a0e416c0104b9c0271ac9834d7349653c96f38715b94fc9bad48641725b149a83e59e77d0e7554cd407bb1771f9d343ce217c596'
