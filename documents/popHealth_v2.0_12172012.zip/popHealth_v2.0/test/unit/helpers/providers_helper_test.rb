require 'test_helper'

class ProvidersHelperTest < ActionView::TestCase
end
