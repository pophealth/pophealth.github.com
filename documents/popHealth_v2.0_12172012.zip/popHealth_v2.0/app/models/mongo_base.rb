class MongoBase
  def self.mongo
    MONGO_DB
  end
end